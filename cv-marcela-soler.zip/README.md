
# CV - Marcela Beatriz Soler

Este proyecto es una página web personal que muestra el currículum de **Marcela Beatriz Soler**.

Está construido en HTML puro, con estilos integrados y animaciones suaves. Incluye información personal, contacto, educación y experiencia laboral.

### 🔗 GitHub Pages

Accedé al CV online desde este enlace:

👉 [https://TU-USUARIO.github.io/cv-marcela-soler/](https://TU-USUARIO.github.io/cv-marcela-soler/)

_Reemplazá `TU-USUARIO` con tu usuario real de GitHub._

### 📁 Archivos incluidos

- `index.html`: Archivo principal con el contenido del CV.
- `68.jpg`: Imagen de perfil.
- `README.md`: Este archivo.

---

💡 Creado con amor por Marcela y desplegado usando **GitHub Pages**.
